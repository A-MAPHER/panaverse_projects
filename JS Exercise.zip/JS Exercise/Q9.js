// 9. Favorite Number: Store your favorite number in a variable. Then, 
// using that variable, create a message that reveals your favorite number. Print that message.


let num = 7;
let message = `This is my favorite number : ${num}`;
console.log(message);
