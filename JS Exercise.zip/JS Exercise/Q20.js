// 20. Think of something you could store in a array. 
// For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. 
// Write a program that creates a list containing these items.

let countries = ["Pakistna", "India","Austrailia","USA"];
let cities = ["Karachi", "Lahore", "Islamabad"];

let languages = ["English", "Urdu", "Sindhi","Balochi"];
let mountains = ["Everest", "K2"];

console.log("Countries : " + countries);
console.log("Cities    : " + cities);
console.log("Languages : " + languages);
console.log("Mountains : " + mountains);