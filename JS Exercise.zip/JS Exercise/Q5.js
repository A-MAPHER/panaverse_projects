// 5. Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. 
// Then compose your message and store it in a new variable called message. Print your message.

let famous_person = "Abhijit Naskar";
console.log(famous_person + " once said, " + "\"No technology that\'s connected to the Internet is unhackable\" ");
