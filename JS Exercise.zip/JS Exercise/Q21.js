// 21. They think of something you could store in a JavaScript Object. 
// Write a program that creates Objects containing these items.

const studentData = {id:1,name:"Ahmed",age:20};

console.log("Student : " , studentData);